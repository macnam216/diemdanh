import cv2
import os
import sys
import numpy as np
import datetime
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QDialog, QApplication, QMainWindow, QMessageBox
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSlot, QTimer, QDate, Qt
import csv
from PyQt5 import QtWidgets
import face_recognition
from datetime import datetime
import mysql.connector
import time
import q_li_nv


class InsertDialog(QtWidgets.QDialog):
    def __init__(self):
        super(InsertDialog, self).__init__()

        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("icon/add1.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setWindowIcon(icon)

        self.QBtn = QtWidgets.QPushButton()
        self.QBtn.setText("Thêm")
        # self.QBtn.setStyleSheet("background: #CCFFFF;\n""height:40px; \n""font-size:18px")

        self.setWindowTitle("Thêm nhân viên")
        self.setFixedWidth(500)
        self.setFixedHeight(500)

        self.QBtn.clicked.connect(self.add_employee)

        layout = QtWidgets.QVBoxLayout()

        self.nameinput = QtWidgets.QLineEdit()
        self.nameinput.setPlaceholderText("Nhập tên *")
        # self.nameinput.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.nameinput)

        self.code = QtWidgets.QLineEdit()
        self.code.setPlaceholderText("Nhập code *")
        # self.code.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.code)

        self.branchinput = QtWidgets.QComboBox()
        self.branchinput.addItem("----Chọn bộ phận----")
        self.branchinput.addItem("Marketing")
        self.branchinput.addItem("Sale")
        self.branchinput.addItem("IT")
        self.branchinput.addItem("Support")
        self.branchinput.addItem("Account")
        self.branchinput.addItem("Manager")
        # self.branchinput.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.branchinput)

        self.mobileinput = QtWidgets.QLineEdit()
        self.onlyInt = QtGui.QIntValidator()
        self.mobileinput.setValidator(self.onlyInt)  # chi nhap dc so
        self.mobileinput.setPlaceholderText("Nhập Số điện thoại")
        # self.mobileinput.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.mobileinput)

        self.addressinput = QtWidgets.QLineEdit()
        self.addressinput.setPlaceholderText("Nhập địa chỉ")
        # self.addressinput.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.addressinput)

        self.status = QtWidgets.QComboBox()
        self.status.addItem("---Chọn quyền truy cập---")
        self.status.addItem("Có")
        self.status.addItem("Không")
        # self.status.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.status)

        self.hoursalary = QtWidgets.QComboBox()
        self.hoursalary.addItem("---Chọn mức lương theo giờ---")
        self.hoursalary.addItem("15.000 vnđ")
        self.hoursalary.addItem("20.000 vnđ")
        self.hoursalary.addItem("30.000 vnđ")
        # self.hoursalary.setStyleSheet(
        #     "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.hoursalary)

        layout.addWidget(self.QBtn)
        self.setLayout(layout)

    def checkExist(self, code, id):
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="1234",
                database="quanlynhanvien"
            )
            self.mycursor = self.mydb.cursor()
            query = "SELECT * FROM quan_li_nv WHERE code = %s "
            if id != '':
                query = query + "and id != %s"
            data = (code)
            if id != '':
                data = (code, id)

            print(query, data)
            self.mycursor.execute(query, data)
            result = self.mycursor.fetchone()

            row_exist = result[0]
            self.mydb.commit()
            self.mycursor.close()
            self.mydb.close()
            return True
        except Exception:
            return False

    def add_employee(self):
        name = self.nameinput.text()
        code = self.code.text()
        branch = self.branchinput.itemText(self.branchinput.currentIndex())
        phone = self.mobileinput.text()
        address = self.addressinput.text()
        status = self.status.itemText(self.status.currentIndex())
        hoursalary = self.hoursalary.itemText(self.hoursalary.currentIndex())
        check = self.checkExist(code, '')
        salary = 0
        if hoursalary == '---Chọn mức lương theo giờ---':
            hoursalary = 0
        elif hoursalary == '15.000 vnđ':
            hoursalary = 15
        elif hoursalary == '20.000 vnđ':
            hoursalary = 20
        else:
            hoursalary = 30

        if status == 'Có':
            status = 1
        elif status == 'Không':
            status = 0
        else:
            status = 2

        if name == '':
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Vui lòng nhập tên.')
        elif branch == '----Chọn bộ phận----':
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Vui lòng chọn bộ phận.')
        elif status == '':
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Vui lòng nhập quyền truy cập.')
        elif check == True:
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Mã nhân viên không được trùng.')
        else:
            try:
                self.close()
                return name, code, branch, phone, address, status, hoursalary, salary
            except Exception:
                QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Không thêm được nhân viên')



class SearchDialog(QtWidgets.QDialog):
    def __init__(self):
        super(SearchDialog, self).__init__()
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("icon/s1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setWindowIcon(icon)

        self.QBtn = QtWidgets.QPushButton()
        self.QBtn.setText("Tìm kiếm")
        self.QBtn.setStyleSheet("background: #CCFFFF;\n""height:40px; \n""font-size:18px")

        self.setWindowTitle("Tìm kiếm nhân viên")
        self.setFixedWidth(300)
        self.setFixedHeight(200)
        self.QBtn.clicked.connect(self.insert_employee)
        layout = QtWidgets.QVBoxLayout()

        self.searchinput = QtWidgets.QLineEdit()
        self.onlyInt = QtGui.QIntValidator()
        self.searchinput.setValidator(self.onlyInt)
        self.searchinput.setPlaceholderText("Nhập mã id cần tìm")
        self.searchinput.setStyleSheet(
            "border:1px solid #00FF00;\n""height:30px; \n""border-radius:8px;\n""font-size:18px")
        layout.addWidget(self.searchinput)
        layout.addWidget(self.QBtn)
        self.setLayout(layout)
        self.id = ''

    def checkPermission(self):
        searchrol = self.searchinput.text()
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="1234",
                database="quanlynhanvien"
            )
            self.mycursor = self.mydb.cursor()

            self.mycursor.execute(
                "SELECT quan_li_nv.status FROM quan_li_nv WHERE quan_li_nv.id =" + str(
                    searchrol))
            row = self.mycursor.fetchone()
            result = row[0]
            self.mydb.commit()
            self.close()
            if result == 1:
                return True
            else:
                return False
        except Exception:
            return False

    def insert_employee(self):
        check = self.checkPermission()
        if check == False:
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Bạn không có quyền sử dụng chức năng này.')
        else:
            try:
                dlg = InsertDialog()
                dlg.exec_()
                name, code, branch, phone, address, status, hoursalary, salary = dlg.add_employee()
                print(name, code, branch, phone, address, status, hoursalary, salary)
                self.mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    passwd="1234",
                    database="quanlynhanvien"
                )
                self.mycursor = self.mydb.cursor()

                self.mycursor.execute(
                    "INSERT INTO quan_li_nv (name,code, branch,phone,address,status,hoursalary) VALUES ('{}','{}','{}','{}','{}','{}','{}') ".format(
                        name, code, branch, phone, address, status, hoursalary))

                self.mycursor.execute("INSERT INTO luong (name,salary) VALUES ('{}','{}') ".format(name, salary))
                key = int(status)
                self.mydb.commit()

                self.mycursor.close()
                self.current_path = os.path.join(os.getcwd(), "datasets", str(key) + "-" + code)
                os.makedirs(self.current_path, exist_ok=True)
                # self.start_timer()
                # self.generate_dataset_btn.setText("Generating")

                # QtWidgets.QMessageBox.information(QtWidgets.QMessageBox(), 'Successful', 'Thêm nhân viên thành công.')

            except Exception:
                self.close()
                # msg = QMessageBox()
                # msg.about(self, "Không thể thêm nhân viên")
                # AUFR().generate_dataset_btn.setChecked(False)


class AUFR(QMainWindow):  # Main application
    """Main Class"""

    def __init__(self):
        super(AUFR, self).__init__()
        loadUi("mainwindow.ui", self)
        self.setWindowTitle("Hệ thống điểm danh dựa trên nhận diện khuôn mặt")
        # Classifiers, frontal face, eyes and smiles.
        self.face_classifier = cv2.CascadeClassifier("classifiers/haarcascade_frontalface_default.xml")
        self.eye_classifier = cv2.CascadeClassifier("classifiers/haarcascade_eye.xml")
        self.smile_classifier = cv2.CascadeClassifier("classifiers/haarcascade_smile.xml")

        # date and time
        now = QDate.currentDate()
        current_date = now.toString('ddd dd MMMM yyyy')
        current_time = datetime.now().strftime("%I:%M %p")
        self.date_label.setText(current_date)
        self.time_label.setText(current_time)

        self.image = None

        # Variables
        self.camera_id = 0  # can also be a url of Video
        self.dataset_per_subject = 50
        self.ret = False
        self.trained_model = 0

        self.image = cv2.imread("icon/app_icon.jpg", 1)
        self.modified_image = self.image.copy()

        self.display()
        # Actions
        self.generate_dataset_btn.setCheckable(True)
        self.train_model_btn.setCheckable(True)
        self.recognize_face_btn.setCheckable(True)
        self.detail_btn.setCheckable(True)
        # Menu
        self.about_menu = self.menu_bar.addAction("About")
        self.help_menu = self.menu_bar.addAction("Help")
        self.about_menu.triggered.connect(self.about_info)
        self.help_menu.triggered.connect(self.help_info)
        # Algorithms
        self.algo_radio_group.buttonClicked.connect(self.algorithm_radio_changed)
        # Recangle
        self.face_rect_radio.setChecked(True)
        self.eye_rect_radio.setChecked(False)
        self.smile_rect_radio.setChecked(False)
        # Events
        # self.generate_dataset_btn.clicked.connect(self.generate)
        self.generate_dataset_btn.clicked.connect(self.insert)
        self.detail_btn.clicked.connect(self.excutetable)
        self.train_model_btn.clicked.connect(self.train)
        self.recognize_face_btn.clicked.connect(self.recognize)
        self.checkin_btn.clicked.connect(self.attendance)
        self.checkout_btn.clicked.connect(self.attendance)
        self.video_recording_btn.clicked.connect(self.save_video)
        # Recognizers
        self.update_recognizer()
        self.assign_algorithms()
        self.id = ''

    def ql_nv_Show(self):
        self.ql_nv_form = QtWidgets.QMainWindow()
        self.ui = q_li_nv.Ui_QMainWindow()
        self.ui.setupUi(self.ql_nv_form)
        self.thread1 = q_li_nv.Thread()
        self.thread1.data.connect(self.ui.callback_function1)
        self.thread1.start()
        self.ql_nv_form.show()

    def excutetable(self):
        if self.detail_btn.isChecked():
            try:
                self.ql_nv_Show()

            except:
                msg = QMessageBox()
                msg.about(self, "Data table", '''pls! \n name[string]\n key[integer]''')
                self.detail_btn.setChecked(False)

    def start_timer(self):  # start the timeer for execution.
        self.capture = cv2.VideoCapture(self.camera_id)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.timer = QtCore.QTimer()
        path = 'ImagesAttendance'
        if not os.path.exists(path):
            os.mkdir(path)
        # known face encoding and known face name list
        images = []
        self.class_names = []
        self.encode_list = []
        self.TimeList1 = []
        self.TimeList2 = []
        attendance_list = os.listdir(path)
        if self.generate_dataset_btn.isChecked():
            self.timer.timeout.connect(self.save_dataset)
        elif self.recognize_face_btn.isChecked():
            self.timer.timeout.connect(self.update_image)
        self.timer.start(5)

    def stop_timer(self):  # stop timer or come out of the loop.
        self.timer.stop()
        self.ret = False
        self.capture.release()

    def update_image(self):  # update canvas every time according to time set in the timer.
        if self.recognize_face_btn.isChecked():
            self.ret, self.image = self.capture.read()
            self.image = cv2.flip(self.image, 1)
            faces = self.get_faces()
            self.draw_rectangle(faces)
        if self.video_recording_btn.isChecked():
            self.recording()
        self.display()

    def caculateHoursWork(self, timeCheckIn, timeCheckOut):
        date_format = "%Y-%m-%d %H:%M:%S"
        checkIn = datetime.strptime(timeCheckIn, date_format)
        checkOut = datetime.strptime(timeCheckOut, date_format)
        diff = checkOut - checkIn
        hours = (diff.seconds) / 3600
        return hours

    def checkLate(self, timeCheckIn):
        # today = datetime.now()
        date_format = "%m-%d-%Y %H:%M:%S"
        time = datetime.strptime('8-02-2008 08:00:00', date_format)
        print(timeCheckIn.hour, time.hour)

        if timeCheckIn.hour < time.hour:
            status = 0
        elif timeCheckIn.hour > time.hour:
            status = 1
        elif timeCheckIn.minute > 0:
            status = timeCheckIn.minute
        else:
            status = 0
        return status

    def fine(self, status, salary):
        if status == 0:
            wages = 0
        else:
            if status == 1:
                wages = salary
            else:
                wages = status * 1000
        return wages

    def fineCheckOut(self, timeCheckOut):
        date_format = "%m-%d-%Y %H:%M:%S"
        time = datetime.strptime('8-02-2008 08:00:00', date_format)
        timeFine = (time.hour * 60 + time.minute) - (timeCheckOut.hour * 60 + timeCheckOut.minute)
        if timeFine <= 0:
            wages = 0
        else:
            wages = timeFine * 1000
        return wages

    def getSalary(self, searchname):
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="1234",
                database="quanlynhanvien"
            )
            self.mycursor = self.mydb.cursor()
            sql = "SELECT quan_li_nv.hoursalary FROM quan_li_nv WHERE code = %s"
            self.mycursor.execute(
                sql, (searchname,))
            row = self.mycursor.fetchone()
            hoursalary = row[0]
            self.mydb.commit()
            return hoursalary * 8000
        except:
            QtWidgets.QMessageBox.warning(QtWidgets.QMessageBox(), 'Error', 'Lỗi khi lấy dữ liệu')

    def attendance(self, roi_gray):
        faces = self.get_faces()
        for (x, y, w, h) in faces:
            roi_gray_original = self.get_gray_image()[y:y + h, x:x + w]
            roi_gray = self.resize_image(roi_gray_original, 92, 112)
            roi_color = self.image[y:y + h, x:x + w]
            predicted, confidence = self.face_recognizer.predict(roi_gray)
            name = self.get_all_key_name_pairs().get(str(predicted))  # Save image captured using the save button.

        if self.checkin_btn.isChecked():
            self.checkin_btn.setEnabled(False)
            with open('Attendance.csv', 'a') as f:
                if (name != 'Unknown'):

                    buttonReply = QMessageBox.question(self, 'Welcome', 'Are you Check In?',
                                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if buttonReply == QMessageBox.Yes:
                        date_time_string_checkIn = datetime.now()
                        status = self.checkLate(date_time_string_checkIn)
                        hoursalary = self.getSalary(name)
                        fine = self.fine(status, hoursalary)
                        month = date_time_string_checkIn.strftime("%m")
                        day = date_time_string_checkIn.strftime("%d")
                        f.writelines(f'\n {name},{date_time_string_checkIn},{fine},{month},Checked In')
                        self.mydb = mysql.connector.connect(
                            host="localhost",
                            user="root",
                            passwd="1234",
                            database="quanlynhanvien"
                        )
                        self.mycursor = self.mydb.cursor()

                        self.mycursor.execute(
                            "INSERT INTO checkInOut (code,timeIn,fine,month,day,status) VALUES ('{}','{}','{}','{}','{}','{}') ".format(
                                name, date_time_string_checkIn, fine, month, day, 'Checked In'))

                        self.mydb.commit()

                        QtWidgets.QMessageBox.information(QtWidgets.QMessageBox(), 'Successful',
                                                          'CheckIN thành công.')

                        self.mycursor.close()

                        self.checkin_btn.setChecked(False)
                        self.name_label.setText(str(name))
                        self.id_label.setText('Check In')

                        self.Time1 = datetime.now()
                        print(self.Time1)
                        self.checkin_btn.setEnabled(True)
                    else:
                        print('Not clicked.')
                        self.checkin_btn.setEnabled(True)
        elif self.checkout_btn.isChecked():
            self.checkout_btn.setEnabled(False)
            with open('Attendance.csv', 'a') as f:
                if (name != 'Unknown'):
                    buttonReply = QMessageBox.question(self, 'Good Bye ', 'Are you Clocking Out?',
                                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if buttonReply == QMessageBox.Yes:
                        date_time_string_checkOut = datetime.now()
                        status = self.checkLate(date_time_string_checkOut)
                        hoursalary = self.getSalary(name)
                        fine = self.fine(status, hoursalary)
                        month = date_time_string_checkOut.strftime("%m")
                        day = date_time_string_checkOut.strftime("%d")
                        f.writelines(f'\n {name},{date_time_string_checkOut},{fine},{month},Checked Out')
                        self.mydb = mysql.connector.connect(
                            host="localhost",
                            user="root",
                            passwd="1234",
                            database="quanlynhanvien"
                        )
                        self.mycursor = self.mydb.cursor()

                        self.mycursor.execute(
                            "INSERT INTO checkInOut (code,timeIn,fine,month,day,status) VALUES ('{}','{}','{}','{}','{}','{}') ".format(
                                name, date_time_string_checkOut, fine, month, day, 'Checked Out'))

                        self.mydb.commit()

                        QtWidgets.QMessageBox.information(QtWidgets.QMessageBox(), 'Successful',
                                                          'CheckOut thành công.')

                        self.mycursor.close()

                        self.checkout_btn.setChecked(False)

                        self.name_label.setText(str(name))
                        self.id_label.setText('Checkin Out')
                        # self.Time2 = datetime.now()
                        # # print(self.Time2)
                        #
                        # self.ElapseList(name)
                        # self.TimeList2.append(datetime.now())
                        # CheckInTime = self.Time1
                        # CheckOutTime = self.Time2
                        # self.ElapseHours = (CheckOutTime - CheckInTime)
                        # self.min_label.setText(
                        #     "{:.0f}".format(abs(self.ElapseHours.total_seconds() / 60) % 60) + 'm')
                        # self.hour_label.setText(
                        #     "{:.0f}".format(abs(self.ElapseHours.total_seconds() / 60 ** 2)) + 'h')
                        self.checkout_btn.setEnabled(True)
                    else:
                        print('Not clicked.')
                        self.checkout_btn.setEnabled(True)

    def ElapseList(self, name):
        with open('Attendance.csv', "r") as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 2

            Time1 = datetime.now()
            Time2 = datetime.now()
            for row in csv_reader:
                for field in row:
                    if field in row:
                        if field == 'Clock In':
                            if row[0] == name:
                                # print(f'\t ROW 0 {row[0]}  ROW 1 {row[1]} ROW2 {row[2]}.')
                                Time1 = (datetime.strptime(row[1], '%y/%m/%d %H:%M:%S'))
                                self.TimeList1.append(Time1)
                        if field == 'Clock Out':
                            if row[0] == name:
                                # print(f'\t ROW 0 {row[0]}  ROW 1 {row[1]} ROW2 {row[2]}.')
                                Time2 = (datetime.strptime(row[1], '%y/%m/%d %H:%M:%S'))
                                self.TimeList2.append(Time2)
                                # print(Time2)

    def save_dataset(self):  # Save images of new dataset generated using generate dataset button.
        location = os.path.join(self.current_path, str(self.dataset_per_subject) + ".jpg")

        if self.dataset_per_subject < 1:
            QMessageBox().about(self, "Dataset Generated",
                                "Your response is recorded now you can train the Model \n or Generate New Dataset.")
            self.generate_dataset_btn.setText("Generate Dataset")
            self.generate_dataset_btn.setChecked(False)
            self.stop_timer()
            self.dataset_per_subject = 50  # again setting max datasets

        if self.generate_dataset_btn.isChecked():
            self.ret, self.image = self.capture.read()
            self.image = cv2.flip(self.image, 1)
            faces = self.get_faces()
            self.draw_rectangle(faces)
            if len(faces) is not 1:
                self.draw_text("Only One Person at a time")
            else:
                for (x, y, w, h) in faces:
                    cv2.imwrite(location, self.resize_image(self.get_gray_image()[y:y + h, x:x + w], 92, 112))
                    self.draw_text("/".join(location.split("/")[-3:]), 20, 20 + self.dataset_per_subject)
                    self.dataset_per_subject -= 1
                    self.progress_bar_generate.setValue(100 - self.dataset_per_subject * 2 % 100)
        if self.video_recording_btn.isChecked():
            self.recording()

        self.display()

    def display(self):  # Display in the canvas, video feed.
        pixImage = self.pix_image(self.image)
        self.video_feed.setPixmap(QtGui.QPixmap.fromImage(pixImage))
        self.video_feed.setScaledContents(True)

    def pix_image(self, image):  # Converting image from OpenCv to PyQT compatible image.
        qformat = QtGui.QImage.Format_RGB888  # only RGB Image
        if len(image.shape) >= 3:
            r, c, ch = image.shape
        else:
            r, c = image.shape
            qformat = QtGui.QImage.Format_Indexed8
        pixImage = QtGui.QImage(image, c, r, image.strides[0], qformat)
        return pixImage.rgbSwapped()

    def generate(self):  # Envoke user dialog and enter name and key.
        if self.generate_dataset_btn.isChecked():
            try:
                user = USER()
                user.exec_()
                name, key, code = user.get_name_key()
                self.current_path = os.path.join(os.getcwd(), "datasets", str(key) + "-" + name + "-" + code)
                os.makedirs(self.current_path, exist_ok=True)
                self.start_timer()
                self.generate_dataset_btn.setText("Generating")
            except:
                msg = QMessageBox()
                msg.about(self, "User Information", '''Provide Information Please! \n name[string]\n key[integer]''')
                self.generate_dataset_btn.setChecked(False)

    def algorithm_radio_changed(
            self):  # When radio button change, either model is training or recognizing in respective algorithm.
        self.assign_algorithms()  # 1. update current radio button
        self.update_recognizer()  # 2. update face Recognizer
        self.read_model()  # 3. read trained data of recognizer set in step 2
        if self.train_model_btn.isChecked():
            self.train()

    def update_recognizer(self):  # whenever algoritm radio buttons changes this function need to be invoked.
        if self.eigen_algo_radio.isChecked():
            self.face_recognizer = cv2.face.EigenFaceRecognizer_create()
        elif self.fisher_algo_radio.isChecked():
            self.face_recognizer = cv2.face.FisherFaceRecognizer_create()
        else:
            self.face_recognizer = cv2.face.LBPHFaceRecognizer_create()

    def assign_algorithms(self):  # Assigning anyone of algorithm to current woring algorithm.
        if self.eigen_algo_radio.isChecked():
            self.algorithm = "EIGEN"
        elif self.fisher_algo_radio.isChecked():
            self.algorithm = "FISHER"
        else:
            self.algorithm = "LBPH"

    def read_model(self):  # Reading trained model.
        if self.recognize_face_btn.isChecked():
            try:  # Need to to invoked when algoritm radio button change
                self.face_recognizer.read("training/" + self.algorithm.lower() + "_trained_model.yml")
            except Exception as e:
                self.print_custom_error("Unable to read Trained Model due to")
                print(e)

    def save_model(self):  # Save anyone model.
        try:
            self.face_recognizer.save("training/" + self.algorithm.lower() + "_trained_model.yml")
            msg = self.algorithm + " model trained, stop training or train another model"
            self.trained_model += 1
            self.progress_bar_train.setValue(self.trained_model)
            QMessageBox().about(self, "Training Completed", msg)
        except Exception as e:
            self.print_custom_error("Unable to save Trained Model due to")
            print(e)

    def train(self):  # When train button is clicked.
        if self.train_model_btn.isChecked():
            button = self.algo_radio_group.checkedButton()
            button.setEnabled(False)
            self.train_model_btn.setText("Stop Training")
            os.makedirs("training", exist_ok=True)
            labels, faces = self.get_labels_and_faces()
            try:
                msg = self.algorithm + " model training started"
                QMessageBox().about(self, "Training Started", msg)

                self.face_recognizer.train(faces, np.array(labels))
                self.save_model()
            except Exception as e:
                self.print_custom_error("Unable To Train the Model Due to: ")
                print(e)
        else:
            self.eigen_algo_radio.setEnabled(True)
            self.fisher_algo_radio.setEnabled(True)
            self.lbph_algo_radio.setEnabled(True)
            self.train_model_btn.setChecked(False)
            self.train_model_btn.setText("Train Model")

    def recognize(self):  # When recognized button is called.
        if self.recognize_face_btn.isChecked():
            self.start_timer()
            self.recognize_face_btn.setText("Stop Recognition")
            self.read_model()
        else:
            self.recognize_face_btn.setText("Recognize Face")
            self.stop_timer()

    def get_all_key_name_pairs(self):  # Get all (key, name) pair of datasets present in datasets.
        return dict(
            [subfolder.split('-') for _, folders, _ in os.walk(os.path.join(os.getcwd(), "datasets")) for subfolder in
             folders], )

    def absolute_path_generator(self):  # Generate all path in dataset folder.
        separator = "-"
        for folder, folders, _ in os.walk(os.path.join(os.getcwd(), "datasets")):
            for subfolder in folders:
                subject_path = os.path.join(folder, subfolder)
                key, _ = subfolder.split(separator)
                for image in os.listdir(subject_path):
                    absolute_path = os.path.join(subject_path, image)
                    yield absolute_path, key

    def get_labels_and_faces(self):  # Get label and faces.
        labels, faces = [], []
        for path, key in self.absolute_path_generator():
            faces.append(cv2.cvtColor(cv2.imread(path), cv2.COLOR_BGR2GRAY))
            labels.append(int(key))
        return labels, faces

    def get_gray_image(self):  # Convert BGR image to GRAY image.
        return cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)

    def get_faces(self):  # Get all faces in a image.
        # variables
        scale_factor = 1.1
        min_neighbors = 8
        min_size = (100, 100)

        faces = self.face_classifier.detectMultiScale(
            self.get_gray_image(),
            scaleFactor=scale_factor,
            minNeighbors=min_neighbors,
            minSize=min_size)

        return faces

    def get_smiles(self, roi_gray):  # Get all smiles in a image.
        scale_factor = 1.7
        min_neighbors = 22
        min_size = (25, 25)
        # window_size = (200, 200)

        smiles = self.smile_classifier.detectMultiScale(
            roi_gray,
            scaleFactor=scale_factor,
            minNeighbors=min_neighbors,
            minSize=min_size
        )

        return smiles

    def get_eyes(self, roi_gray):  # Get all eyes in a image.
        scale_factor = 1.1
        min_neighbors = 6
        min_size = (30, 30)

        eyes = self.eye_classifier.detectMultiScale(
            roi_gray,
            scaleFactor=scale_factor,
            minNeighbors=min_neighbors,
            # minSize = min_size
        )

        return eyes

    def draw_rectangle(self, faces):  # Draw rectangle either in face, eyes or smile.
        for (x, y, w, h) in faces:
            roi_gray_original = self.get_gray_image()[y:y + h, x:x + w]
            roi_gray = self.resize_image(roi_gray_original, 92, 112)
            roi_color = self.image[y:y + h, x:x + w]
            if self.recognize_face_btn.isChecked():
                try:
                    predicted, confidence = self.face_recognizer.predict(roi_gray)
                    name = self.get_all_key_name_pairs().get(str(predicted))
                    self.draw_text("Recognizing using: " + self.algorithm, 70, 50)
                    if self.lbph_algo_radio.isChecked():
                        if confidence > 80:
                            msg = "Unknown"
                        else:
                            confidence = "{:.2f}".format(100 - confidence)
                            msg = name
                        self.progress_bar_recognize.setValue(float(confidence))
                    else:
                        msg = name
                        self.progress_bar_recognize.setValue(int(confidence % 100))
                        confidence = "{:.2f}".format(confidence)

                    self.draw_text(msg, x - 5, y - 5)
                except Exception as e:
                    self.print_custom_error("Unable to Pridict due to")
                    print(e)

            if self.eye_rect_radio.isChecked():  # If eye radio button is checked.
                eyes = self.get_eyes(roi_gray_original)
                for (ex, ey, ew, eh) in eyes:
                    cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)
            elif self.smile_rect_radio.isChecked():  # If smile radio button is checked.
                smiles = self.get_smiles(roi_gray_original)
                for (sx, sy, sw, sh) in smiles:
                    cv2.rectangle(roi_color, (sx, sy), (sx + sw, sy + sh), (0, 255, 0), 2)
            else:  # If face radio button is checked.
                cv2.rectangle(self.image, (x, y), (x + w, y + h), (0, 255, 0), 2)

    def time(self):  # Get current time.
        return datetime.now().strftime("%d-%b-%Y:%I-%M-%S")

    def draw_text(self, text, x=20, y=20, font_size=2,
                  color=(0, 255, 0)):  # Draw text in current image in particular color.
        cv2.putText(self.image, text, (x, y), cv2.FONT_HERSHEY_PLAIN, 1.6, color, font_size)

    def resize_image(self, image, width=280, height=280):  # Resize image before storing.
        return cv2.resize(image, (width, height), interpolation=cv2.INTER_CUBIC)

    def print_custom_error(self, msg):  # Print custom error message/
        print("=" * 100)
        print(msg)
        print("=" * 100)

    def recording(self):  # Record Video when either recognizing or generating.
        if self.ret:
            self.video_output.write(self.image)

    def save_video(self):  # Saving video.
        if self.video_recording_btn.isChecked() and self.ret:
            self.video_recording_btn.setText("Stop")
            try:
                fourcc = cv2.VideoWriter_fourcc(*'XVID')
                output_file_name = self.time() + '.avi'
                path = os.path.join(os.getcwd(), "recordings")
                os.makedirs(path, exist_ok=True)
                self.video_output = cv2.VideoWriter(os.path.join(path, output_file_name), fourcc, 20.0, (640, 480))
            except Exception as e:
                self.print_custom_error("Unable to Record Video Due to")
                print(e)
        else:
            self.video_recording_btn.setText("Record")
            self.video_recording_btn.setChecked(False)
            if self.ret:
                QMessageBox().about(self, "Recording Complete",
                                    "Video clip successfully recorded into current recording folder")
            else:
                QMessageBox().about(self, "Information", '''Start either datasets generation or recognition First!  ''')

    # Main Menu
    def about_info(self):  # Menu Information of info button of application.
        msg_box = QMessageBox()
        msg_box.setText('''
            Face Recognition Attendance System
        ''')
        msg_box.setInformativeText('''
            Học Viện Kỹ Thuật Mật Mã
            Lập Trình Hệ Thống Nhúng Linux-CT201
            Giáo viên hướng dẫn: Lê Hồng Vân
            Mạc Văn Nam
            ''')
        msg_box.setWindowTitle("About")
        msg_box.exec_()

    def help_info(self):  # Menu Information of help button of application.
        msg_box = QMessageBox()
        msg_box.setText('''
            Phần mềm này có khả năng tạo tập dữ liệu, tạo mô hình, nhận diện các khuôn mặt.
            Phần mềm cũng bao gồm các chức năng nhận diện khuôn mặt, đôi mắt, khóe miệng cười.
        ''')
        msg_box.setInformativeText('''
            Làm theo các bước sau để sử dụng phần mềm
            1. Tạo ít nhất hai bộ dữ liệu.
            2. Huấn luyện tất cả các mô hình xử lý ảnh bằng cách sử dụng 3 nút radio đã cho.
            3. Nhận diện khuôn mặt.

            ''')
        msg_box.setWindowTitle("Help")
        msg_box.exec_()

    def insert(self):
        if self.generate_dataset_btn.isChecked():
            self.id = 'insert'
            # self.ql_nv_Show()
            dlg = SearchDialog()
            dlg.id = self.id
            dlg.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ui = AUFR()  # Running application loop.
    ui.show()
    sys.exit(app.exec_())  # Exit application.
