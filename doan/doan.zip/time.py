from datetime import datetime

#set the date and time format

date_format = "%Y-%m-%d %H:%M:%S"
now = datetime.now()

#convert string to actual date and time
time1  = datetime.strptime('2008-01-8 00:00:00', date_format)
time2  = datetime.strptime('2008-02-8 01:30:00', date_format)
time3 = now.strftime(date_format)

#find the difference between two dates


print ('\nTime difference between two times (date is not considered)')


print(time2.strftime("%m"))
print(time2.strftime("%d"))



