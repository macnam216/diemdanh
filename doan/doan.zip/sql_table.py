import sys
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication
from PyQt5.QtCore import Qt
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="nam",
    password="1234",
    database="nhanvien"
)
class MainWindow(QDialog):
    def __init__(self):
        super(MainWindow, self).__init__()
        loadUi("tabletutorial.ui",self)
        self.tableWidget.setColumnWidth(0, 50)
        self.tableWidget.setColumnWidth(1, 100)
        self.tableWidget.setColumnWidth(2, 100)
        self.tableWidget.setColumnWidth(3, 200)
        self.tableWidget.setHorizontalHeaderLabels(["stt","name","date","status"])
        self.loaddatabyname()
        self.search_btn.clicked.connect(self.loaddatabyname)

    # def loaddata(self):
    #     mycursor = mydb.cursor()
    #     sqlstr = "select stt,name,date,status from nhanvien  "
    #     tablerow=0
    #     mycursor.execute(sqlstr)
    #     results = mycursor.fetchall()
    #     self.tableWidget.setRowCount(20)
    #     self.tableWidget.setColumnCount(4)
    #     for row in results:
    #         self.tableWidget.setItem(tablerow, 0, QtWidgets.QTableWidgetItem(row[0]))
    #         self.tableWidget.setItem(tablerow, 1, QtWidgets.QTableWidgetItem(row[1]))
    #         self.tableWidget.setItem(tablerow, 2, QtWidgets.QTableWidgetItem(row[2]))
    #         self.tableWidget.setItem(tablerow, 3, QtWidgets.QTableWidgetItem(row[3]))
    #         tablerow+=1
    def loaddatabyname(self):
        key = self.lineEdit.text()
        s="\'"+ key +"\'"
        mycursor = mydb.cursor()
        sqlstr = "select stt,name,date,status from nhanvien where name = %s "
        # val=("\'thang\'",)
        val=(s,)
        tablerow=0
        mycursor.execute(sqlstr,val)
        results = mycursor.fetchall()
        self.tableWidget.setRowHidden(tablerow, True)
        self.tableWidget.setRowCount(20)
        self.tableWidget.setColumnCount(4)
        for row in results:
            self.tableWidget.setItem(tablerow, 0, QtWidgets.QTableWidgetItem(row[0]))
            self.tableWidget.setItem(tablerow, 1, QtWidgets.QTableWidgetItem(row[1]))
            self.tableWidget.setItem(tablerow, 2, QtWidgets.QTableWidgetItem(row[2]))
            self.tableWidget.setItem(tablerow, 3, QtWidgets.QTableWidgetItem(row[3]))
            tablerow+=1
# main
app = QApplication(sys.argv)
mainwindow = MainWindow()
widget = QtWidgets.QStackedWidget()
widget.addWidget(mainwindow)
widget.setFixedHeight(500)
widget.setFixedWidth(700)
widget.show()
try:
    sys.exit(app.exec_())
except:
    print("Exiting")
