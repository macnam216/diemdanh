History
=======

0.1.11 (2017-03-30)
-------------------

* Fixed a minor bug in the command-line interface.


0.1.10 (2017-03-21)
-------------------

* Minor pref improvements with face comparisons.
* Test updates.


0.1.9 (2017-03-16)
------------------

* Fix minimum scipy version required.


0.1.8 (2017-03-16)
------------------

* Fix missing Pillow dependency.


0.1.7 (2017-03-13)
------------------

* First working release.
